# p2sh-convert
A simple website that converts between old and new p2sh addresses
