Litecoin.org Web Site

This is a tiny NodeJS server that resides on top of ExpressJS and EJS.
