'use strict';

var gulp_bitcore = require('bitcore-build');

gulp_bitcore('payment-protocol');
