# litecoin-detached-sigs
